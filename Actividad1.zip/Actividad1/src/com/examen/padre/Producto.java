package com.examen.padre;

public class Producto {
    private int unidadesEnStock;
    private int unidadesEnPedido;
    private String fechaCaducidad;
    
    public Producto() {
    }
    
    public Producto(int unidadesEnStock, int unidadesEnPedido, String fechaCaducidad) {
        this.unidadesEnStock = unidadesEnStock;
        this.unidadesEnPedido = unidadesEnPedido;
        this.fechaCaducidad = fechaCaducidad;
    }
    
    public int getUnidadesEnStock() {
        return unidadesEnStock;
    }
    
    public void setUnidadesEnStock(int unidadesEnStock) {
        this.unidadesEnStock = unidadesEnStock;
    }
    
    public int getUnidadesEnPedido() {
        return unidadesEnPedido;
    }
    
    public void setUnidadesEnPedido(int unidadesEnPedido) {
        this.unidadesEnPedido = unidadesEnPedido;
    }
    
    public String getFechaCaducidad() {
        return fechaCaducidad;
    }
    
    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }
}


