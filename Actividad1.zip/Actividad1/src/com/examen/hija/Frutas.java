package com.examen.hija;

import com.examen.Inventario;
import com.examen.padre.Producto;

public class Frutas extends Producto implements Inventario {
    private String nombreProducto;
    private double precioUnitario;
    
    public Frutas() {
    }
    
    public Frutas(String nombreProducto, double precioUnitario, int unidadesEnStock, int unidadesEnPedido, String fechaCaducidad) {
        super(unidadesEnStock, unidadesEnPedido, fechaCaducidad);
        this.nombreProducto = nombreProducto;
        this.precioUnitario = precioUnitario;
    }
    
    public String getNombreProducto() {
        return nombreProducto;
    }
    
    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
    
    public double getPrecioUnitario() {
        return precioUnitario;
    }
    
    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    
    @Override
    public double calcularValorInventario() {
        return getUnidadesEnStock() * getPrecioUnitario();
    }
}






