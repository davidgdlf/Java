package com.examen;
import com.examen.hija.Frutas;

public class Tienda {
    public static void main(String[] args) {
        Frutas manzana = new Frutas("Manzana", 9.95, 100, 80, "15/03/2021");
        Frutas peras = new Frutas("Peras", 15.95, 150, 95, "21/03/2021");
        Frutas naranjas = new Frutas("Naranjas", 7.95, 100, 75, "20/03/2021");
        
        
        System.out.println("Productos agregados:");
        System.out.println(manzana.getNombreProducto() + " - Stock: " + manzana.getUnidadesEnStock() + " - Pedido: " + manzana.getUnidadesEnPedido() + " - Caducidad: " + manzana.getFechaCaducidad() + " - Precio: " + manzana.getPrecioUnitario());
        System.out.println(peras.getNombreProducto() + " - Stock: " + peras.getUnidadesEnStock() + " - Pedido: " + peras.getUnidadesEnPedido() + " - Caducidad: " + peras.getFechaCaducidad() + " - Precio: " + peras.getPrecioUnitario());
        System.out.println(naranjas.getNombreProducto() + " - Stock: " + naranjas.getUnidadesEnStock() + " - Pedido: " + naranjas.getUnidadesEnPedido() + " - Caducidad: " + naranjas.getFechaCaducidad() + " - Precio: " + naranjas.getPrecioUnitario());
        
 
        Inventario[] inventario = { manzana, peras, naranjas };
        double totalInventario = 0;
        for (Inventario item : inventario) {
            totalInventario += item.calcularValorInventario();
        }
        
        System.out.println("Total del inventario valorado por su precio: " + totalInventario);
    }
}


