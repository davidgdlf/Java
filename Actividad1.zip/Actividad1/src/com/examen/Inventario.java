package com.examen;

public interface Inventario {
    double calcularValorInventario();
}

